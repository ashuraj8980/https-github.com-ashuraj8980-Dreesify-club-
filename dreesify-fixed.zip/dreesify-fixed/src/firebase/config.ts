import { initializeApp, getApps } from "firebase/app";
import { getAnalytics, isSupported } from "firebase/analytics";

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || "AIzaSyCjRSpDtLxe8zDd9uqN64WSUVaVTfrmhe0",
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || "ashu-7d0cd.firebaseapp.com",
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || "ashu-7d0cd",
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || "ashu-7d0cd.firebasestorage.app",
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || "843418580808",
  appId: import.meta.env.VITE_FIREBASE_APP_ID || "1:843418580808:web:d1128486fd5003d307257d",
  measurementId: import.meta.env.VITE_FIREBASE_MEASUREMENT_ID || "G-43HWGRGYX2",
};

// Prevent duplicate Firebase app initialization
const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApps()[0];

// Analytics only in browser, only if supported
let analytics = null;
if (typeof window !== 'undefined') {
  isSupported().then(yes => {
    if (yes) {
      analytics = getAnalytics(app);
    }
  });
}

export { app, analytics };
